import styled from "styled-components";
import clsx from "classnames";
import { ReactComponent as MetaMask } from "assets/images/metamask.svg";
import { ReactComponent as WalletConnect } from "assets/images/wallet-connect.svg";

const BackDrop = styled.div`
  height: 100vh;
  width: 100vw;
  background: rgba(0, 0, 0, 0.8);
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  pointer-events: none;
  transition: 0.4s ease;
`;

const Wrapper = styled.div`
  background: #0d0929;
  border: 1.5px solid rgba(128, 118, 255, 0.5);
  box-shadow: 0px 30px 65px #0d0929;
  transition: 0.4s ease;
`;

const ConnectWalletModal = ({ active, onClose, onSelect }) => {
  const options = [
    { text: "METAMASK", logo: <MetaMask className="h-[100px] md:h-auto" /> },
    {
      text: "Wallet Connect",
      logo: <WalletConnect className="h-[100px] md:h-auto" />,
    },
  ];
  return (
    <>
      <BackDrop
        className={clsx("z-[1000]", {
          "!opacity-[1] !pointer-events-auto cursor-pointer": active,
        })}
        onClick={onClose}
      ></BackDrop>

      <Wrapper
        className={clsx(
          "w-full mid:mx-5 lg:w-[940px] lg:mx-0 mid:py-[50px] fixed left-[50%] top-5 mid:top-[25%] translate-x-[-50%] z-[1001] mid:px-[100px] opacity-0 pointer-events-none",
          { "!opacity-[1] !pointer-events-auto": active }
        )}
      >
        <h2 className="text-white text-center text-[38px] font-vectro-bold uppercase mb-[60px]">
          Select A Provider
        </h2>
        <div className="flex justify-between px-6 md:space-y-0">
          {options.map((option, index) => (
            <div
              className="cursor-pointer flex flex-col items-center justify-center space-y-5 md:space-y-[44.33px]"
              key={index}
              onClick={() => {
                onSelect(option.text);
                document.getElementById("connection_options")?.scrollIntoView();
              }}
            >
              {option.logo}
              <span className="text-7 mid:text-[35px] text-center font-vectro-bold text-white">
                {option.text}
              </span>
            </div>
          ))}
        </div>
      </Wrapper>
    </>
  );
};

export default ConnectWalletModal;
