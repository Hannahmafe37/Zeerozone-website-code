import styled from "styled-components";
import clsx from "classnames";
import NumberFormat from "react-number-format";
import { ReactComponent as Exit } from "assets/icons/exit.svg";
import { useEffect, useRef, useState } from "react";

const BackDrop = styled.div`
  height: 100vh;
  width: 100vw;
  background: rgba(0, 0, 0, 0.8);
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  pointer-events: none;
  transition: 0.4s ease;
`;

const Wrapper = styled.div`
  background: #0d0929;
  border: 1.5px solid rgba(128, 118, 255, 0.5);
  box-shadow: 0px 30px 65px #0d0929;
  transition: 0.4s ease;
  border-radius: 12px;
`;

const ExchangeModal = ({ active, onClose, otherCurrency }) => {
  const [buying, setBuying] = useState(null);
  const buyingRef = useRef();
  useEffect(() => {
    if (!active) {
      setBuying(null);
    } else {
      buyingRef?.current?.focus();
    }
  }, [active]);
  return (
    <>
      <BackDrop
        className={clsx("z-[1000]", {
          "!opacity-[1] !pointer-events-auto cursor-pointer": active,
        })}
        onClick={onClose}
      ></BackDrop>

      <Wrapper
        className={clsx(
          "w-full mid:mx-5 lg:w-[940px] lg:mx-0 py-[50px] fixed left-[50%] top-5 mid:top-[25%] translate-x-[-50%] z-[1001] px-[100px] opacity-0 pointer-events-none",
          { "!opacity-[1] !pointer-events-auto": active }
        )}
      >
        <div className="flex items-center justify-between">
          <h3 className="font-zona-regular text-white text-[25px]">Exchange</h3>
          <Exit className="cursor-pointer" onClick={onClose} />
        </div>
        <div className="mt-[39px]">
          <div className="mb-[18px]">
            <label className="uppercase font-vectro-bold text-white/[.6] text-[18px] mb-[3px]">
              buying
            </label>
            <div className="input-wrapper flex items-center bg-[#957AFF]/[.2] px-4">
              <NumberFormat
                allowNegative={false}
                onValueChange={({ value }) => setBuying(value)}
                value={buying}
                thousandSeparator={","}
                getInputRef={buyingRef}
                className="flex-1 w-full outline-none bg-transparent h-[70px] text-white font-vectro-bold text-[22px]"
              />
              <span className="ml-3 text-white uppercase font-vectro-bold text-[12px]">
                {"ZEZO"}
              </span>
            </div>
          </div>
          {/* selling */}
          <div>
            <label className="uppercase font-vectro-bold text-white/[.6] text-[18px] mb-[3px]">
              selling
            </label>
            <div className="input-wrapper flex items-center bg-[#957AFF]/[.2] px-4">
              <NumberFormat
                allowNegative={false}
                value={buying}
                disabled={true}
                thousandSeparator=","
                className="flex-1 w-full outline-none h-[70px] bg-transparent  text-white font-vectro-bold text-[22px]"
              />
              <span className="ml-3 text-white uppercase font-vectro-bold text-[12px]">
                {otherCurrency}
              </span>
            </div>
          </div>
        </div>
      </Wrapper>
    </>
  );
};

export default ExchangeModal;
