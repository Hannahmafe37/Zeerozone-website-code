import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { CopyToClipboard } from "react-copy-to-clipboard";
import { useLocation, useNavigate } from "react-router-dom";
import largeEarth from "assets/images/large-earth.png";
import largeEarthCover from "assets/images/large-earth-cover.png";
import TopNav from "pages/home/components/TopNav";
import rings from "assets/images/rings.png";
import copy from "assets/icons/copy.png";
import { buyOptions, walletAddress } from "utils/constants";
import Footer from "pages/home/components/Footer";
import ConnectWalletModal from "components/ConnectWalletModal";
import ExchangeModal from "components/ExchangeModal";

const BuyPage = () => {
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [, setConnectionMode] = useState(null);
  const [selectedBuyMethod, setSelectedBuyMethod] = useState(null);
  const navigate = useNavigate();

  const onSelectConnectionMode = (mode) => {
    setShowConnectModal(false);
    setConnectionMode(mode);
    navigate("/buy/options");
  };
  const { pathname } = useLocation();
  const isBuyOptionsStage = pathname === "/buy/options";

  useEffect(() => {
    return () => setConnectionMode(null);
  }, []);

  return (
    <div>
      <TopNav />
      <div className="flex flex-col mid:flex-row mt-[100px] z-[1] relative">
        <div className="mid:w-[60%] px-[20px] mid:pl-[70px]">
          <h1 className="text-header md:text-large text-white text-center mid:text-left leading-none">
            GET IN EARLY ON
          </h1>
          <br />
          <h1 className="text-header md:text-large text-white text-center mid:text-left leading-none">
            THE
            <span className="text-blue text-center"> ZEEROZONE PRE-SALE</span>
          </h1>
          <p className="pt-5 pr-[20px] md:pr-5 text-center mid:text-left text-white mb-[19px]">
            The presale of the most anticipated gamefi release of the year is
            now live and it couldn’t be easier for you to get involved!
          </p>
          <p className="text-white text-center mid:text-left mb-6">
            1 USDT = 66.67 ZEZO
          </p>
          <div className="flex flex-col space-y-[28px]">
            <span className="text-white text-center mid:text-left">
              USDT Raised : $4,072,869.985 / $4,750,000
            </span>
            <div className="loader-outer h-[30px] mid:h-[55px] mx-auto mid:mx-0 w-[90%] mid:w-[486px] bg-darkblue">
              <div className="h-full w-[60%] mid:w-[376px] bg-purple" />
            </div>
          </div>
        </div>
        <div className="mid:w-[40%]">
          <div
            className="relative w-full h-full uranus"
            id="connection_options"
          >
            {!isBuyOptionsStage ? (
              <div className="h-[700px] mid:absolute mid:translate-x-[50px] right-0 top-0 w-full md:h-full flex flex-col items-center justify-center">
                <h3 className="text-white font-vectro-bold text-center text-[45px]">
                  45,142,001
                </h3>
                <h3 className="text-white mt-[29px] font-vectro-bold text-center text-[45px]">
                  ZEZO REMAINING
                </h3>
                <h3 className="text-white mt-[34px] font-vectro-bold text-center text-[35px]">
                  UNTIL 1 USDT=57.14 ZEZO
                </h3>
              </div>
            ) : (
              <div className="mid:absolute mt-5 mid:mt-0 mid:translate-x-[50px] right-0 top-0 w-full h-full flex flex-col space-y-5 mid:space-y-[55px] items-center justify-center">
                {buyOptions.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedBuyMethod(option)}
                    className="border-0 text-5 mid:text-[30px] gradient-btn font-vectro-bold w-fit text-white py-3 px-3 mid:py-[23px] mid:px-[27px] flex items-center justify-center"
                  >
                    {`BUY ZEEROZONE WITH ${option}`}
                  </button>
                ))}
              </div>
            )}
          </div>
          {!isBuyOptionsStage && (
            <div className="flex items-center justify-center">
              <button
                className="border-0 outline-none gradient-btn px-[60px] py-[18px] text-[32px] font-vectro-bold text-white flex items-center justify-center"
                onClick={() => setShowConnectModal(true)}
              >
                CONNECT WALLET
              </button>
            </div>
          )}
        </div>
      </div>
      {/* instructions */}
      <ConnectWalletModal
        active={showConnectModal}
        onClose={() => setShowConnectModal(false)}
        onSelect={onSelectConnectionMode}
      />
      <ExchangeModal
        otherCurrency={selectedBuyMethod}
        active={!!selectedBuyMethod}
        onClose={() => setSelectedBuyMethod(null)}
      />
      <div className="relative overflow-hidden">
        <div className="absolute z-0 w-full flex items-center justify-center top-[-420px]">
          <img src={rings} alt="rings" />
        </div>
        <div className="mt-[50px] mid:mt-[200px] z-[1] relative">
          <h2 className="text-[40px] mid:text-[80px] text-center font-vectro-bold text-white leading-none">
            how to buy
            <br />
            <span className="text-blue">zeerozone?</span>
          </h2>
          <div className="mt-[30px] mid:mt-[77px] flex flex-col space-y-[112px] relative">
            <img
              src={largeEarth}
              alt="Large earth"
              className="absolute right-0 top-[200px] z-[-1] hidden md:block"
            />
            <img
              src={largeEarthCover}
              alt="Large earth"
              className="absolute right-[-20px] top-[0] z-[-1] hidden md:block"
            />
            <div className="gradient-div w-[90%] mid:w-[1157px] mx-auto  mid:py-[35px] mid:px-[60px] py-[15px] px-[15px]">
              <h2 className="text-white font-vectro-bold text-[40px] mid:text-[60px] uppercase text-center mb-[20px] mid:mb-[42px]">
                Step 1
              </h2>
              <div className="flex flex-col space-y-5">
                <p className="text-[18px] mid:text-[24px] text-lightblue font-zona-regular text-center">
                  To purchase $ZEZO tokens you will first need to create a
                  cryptocurrency wallet. Some of the most popular wallets
                  include Metamask and Trust Wallet.
                </p>
                {/* <p className="text-[18px] mid:text-[24px] text-lightblue font-zona-regular text-center">
                  Purchasing on a desktop browser will give you a smoother
                  purchasing experience. For this we recommend Metamask.
                </p>
                <p className="text-[18px] mid:text-[24px] text-lightblue font-zona-regular text-center">
                  If you are purchasing on mobile, we recommend using Trust
                  Wallet and connecting through the in built browser (just copy
                  https:// into the Trust Wallet Browser).
                </p> */}
              </div>
            </div>
            <div className="gradient-div w-[90%] mid:w-[1157px] mx-auto  mid:py-[35px] mid:px-[60px] py-[15px] px-[15px]">
              <h2 className="text-white font-vectro-bold text-[40px] mid:text-[60px] uppercase text-center mb-[20px] mid:mb-[42px]">
                Step 2
              </h2>
              <div className="flex flex-col space-y-5">
                <p className="text-[18px] mid:text-[24px] text-lightblue font-zona-regular text-center">
                  You should now load up your wallet with the cryptocurrency you
                  wish to purchase $ZEZO with, we recommend BNB.
                </p>
                {/* <p className="text-[18px] mid:text-[24px] text-lightblue font-zona-regular text-center">
                  You will then have 1 option
                </p> */}
                {/* <p className="text-[18px] mid:text-[24px] text-lightblue font-zona-regular text-center">
                  <span className="font-zona-bold">Buy BNB With Card</span>
                  <p className="mt-[10px]">
                    This option will allow you to purchase BNB that will be sent
                    to your wallet by our partner, Transak. You will then be
                    able to use this BNB to purchase ZEZO . Click “Buy BNB With
                    Card” to begin and follow the on screen steps. We recommend
                    purchasing a minimum of $15 worth of BNB to cover the
                    minimum ZEZO purchase.
                  </p>
                </p> */}
                {/* <p className="text-[18px] mid:text-[24px] text-lightblue font-zona-regular text-center">
                  <span className="font-zona-bold">Buy ZEZO With BNB.</span>
                  <p className="mt-[10px]">
                    Once you have sufficient BNB in your wallet (if you do not
                    have BNB or USDT, please select option 1 to purchase BNB
                    first), you can now swap your BNB for ZEZO. Type in the
                    amount of ZEZO you wish to purchase (1,000 minimum) and then
                    click “Convert BNB. Your wallet provider will ask you to
                    confirm the transaction and will also show you the cost of
                    gas
                  </p>
                </p> */}
                {/* <p className="text-[18px] mid:text-[24px] text-lightblue font-zona-regular text-center">
                  <span className="font-zona-bold">Buy ZEZO with USDT.</span>
                  <p className="mt-[10px]">
                    Please ensure you have at least $15 of USDT in your wallet
                    before commencing the transaction. Type in the amount of
                    ZEZO you wish to purchase (1,000 minimum). Click “Convert
                    USDT”. You will then be asked to approve the purchase TWICE.
                    The first approval is for the USDT contract and the second
                    is for the transaction amount. Please ensure you go through
                    both approval steps in order to complete the transaction.
                  </p>
                </p> */}
              </div>
            </div>
            <div className="gradient-div w-[90%] mid:w-[1157px] mx-auto  mid:py-[35px] mid:px-[60px] py-[15px] px-[15px]">
              <h2 className="text-white font-vectro-bold text-[60px] uppercase text-center mb-[42px]">
                Step 3
              </h2>
              <div className="flex flex-col space-y-5">
                <p className="text-[18px] mid:text-[24px] text-lightblue font-zona-regular text-center">
                  Once your wallet is loaded, simply click the connect wallet
                  button at the top of the website and select the wallet you
                  have chosen, you will be taken to another pop-up.
                </p>
              </div>
            </div>
            <div className="gradient-div w-[90%] mid:w-[1157px] mx-auto  mid:py-[35px] mid:px-[60px] py-[15px] px-[15px]">
              <h2 className="text-white font-vectro-bold text-[60px] uppercase text-center mb-[42px]">
                Step 4
              </h2>
              <div className="flex flex-col space-y-5">
                <p className="text-[18px] mid:text-[24px] text-lightblue font-zona-regular text-center">
                  Double check everything looks correct and then click the buy
                  button. After a few seconds, your transaction should go
                  through.
                </p>
              </div>
            </div>
            <div className="gradient-div w-[90%] mid:w-[1157px] mx-auto  mid:py-[35px] mid:px-[60px] py-[15px] px-[15px]">
              <h2 className="text-white font-vectro-bold text-[60px] uppercase text-center mb-[42px]">
                Step 5
              </h2>
              <div className="flex flex-col space-y-5">
                <p className="text-[18px] mid:text-[24px] text-lightblue font-zona-regular text-center">
                  You have now purchased $ZEZO! Once the presale has ended you
                  will be able to find your tokens by clicking the ‘Receive’
                  button on the main website. They are now yours to do with how
                  you will.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-[153px] mb-[300px]">
          <h2 className="font-vectro-bold text-white text-center uppercase text-[30px] mb-5 mid:text-[80px] mid:mb-[73px]">
            <span className="text-blue">zeerozone</span> CONTRACT
          </h2>
          <p className="text-white font-zona-regular text-center">
            Use the contract information below to add the ZEZO token to your
            wallet.
            <br />
            <br />
            <div className="flex items-center space-x-2 justify-center pd overflow-hidden">
              <span className="text-ellipsis max-w-[80%] overflow-hidden">
                Address: {walletAddress}
              </span>
              <CopyToClipboard
                text={walletAddress}
                onCopy={() => toast.success("Address copied successfully!")}
              >
                <img
                  src={copy}
                  alt="Copy wallet address"
                  className="select-none h-[25px] cursor-pointer"
                />
              </CopyToClipboard>
            </div>
            <br />
            <br />
            Decimals: 18
            <br />
            <br />
            Token symbol: ZEZO
          </p>
        </div>
        <Footer />
      </div>
    </div>
  );
};

export default BuyPage;
