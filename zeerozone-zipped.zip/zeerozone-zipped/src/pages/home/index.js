/* eslint-disable jsx-a11y/anchor-is-valid */
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { ReactComponent as ZeeroZone } from "assets/images/zeerozone.svg";
import SpaceShip from "assets/images/spaceship.png";
import LargeSpaceShip from "assets/images/large-spaceship.png";
import Uranus from "assets/images/uranus.png";
import Mars from "assets/images/mars.png";
import SpaceShip2 from "assets/images/spaceship2.png";
import Earth from "assets/images/earth.png";
import LargeEarth from "assets/images/large-earth.png";
import { ReactComponent as Space } from "assets/images/space.svg";
import { ReactComponent as Diamond } from "assets/icons/diamond.svg";
import { ReactComponent as LargeDiamond } from "assets/icons/large-diamond.svg";

import { ReactComponent as Completed } from "assets/icons/roadmap/completed.svg";
import { ReactComponent as Uncompleted } from "assets/icons/roadmap/uncompleted.svg";
import { ReactComponent as SpaceShipControls } from "assets/images/spaceship-controls.svg";
import { ReactComponent as ClockIcon } from "assets/icons/clock-icon.svg";

import {
  bolden,
  faqs,
  roadmaps,
  zeeroZoneBenefits,
  ZeeroZoneFeatures,
} from "utils/constants";
import { initializeAccordions } from "utils/functions";
import Benefit from "./components/Benefit";
import TopNav from "./components/TopNav";
import Footer from "./components/Footer";

const Home = () => {
  useEffect(() => {
    initializeAccordions();
    return () => localStorage.removeItem("INITIALIZED_ACCORDIONS");
  }, []);
  // const [showMiniCountdown, setShowMiniCountdown] = useState(false);
  return (
    <div>
      {/* <div className="hidden md:block">
        <PresaleCountdown />
      </div> */}
      <TopNav />
      <div className="md:hidden mt-3 flex items-center">
        <div
          className="flex flex-col space-y-[2px] ml-auto rounded-tl-[1px] rounded-bl-[1px] cursor-pointer"
          // onClick={() => setShowMiniCountdown(!showMiniCountdown)}
        >
          <span className="text-white uppercase text-[12px] font-vectro-bold">
            presale
          </span>
          <div className="w-[41px] h-[21px] flex items-center justify-center tiny-countdown">
            <ClockIcon />
          </div>
        </div>
      </div>
      <div className="mt-[40px] md:mt-[76.72px]">
        {/* {showMiniCountdown && (
          <div className="md:hidden px-[14px]">
            <PresaleCountdown />
          </div>
        )} */}
        <div className="pd">
          <h1 className="text-header md:text-large text-white text-center leading-none">
            ZEEROZONE IS A
          </h1>
          <h1 className="text-header md:text-large text-blue text-center leading-none">
            BLOCKCHAIN-BASED
            <br className="md:hidden" />
            <span className="text-white text-center"> ONLINE GAME</span>
          </h1>
        </div>
        <p className="pd mt-8 font-zona-regular text-base text-center mx-auto text-lightblue w-[252px] md:w-[449px]">
          Zeerozone is empowers players to explore space, take ownership of the
          planets, and navigate the galaxies.
        </p>
        <div className="pd mt-5 flex items-center justify-center">
          <Link
            className="text-white flex items-center justify-between text-mid bg-blue uppercase py-[10px] px-[20px] rounded font-vectro-bold"
            to="/buy"
          >
            Buy pre-sale
          </Link>
        </div>
        <div className="h-[500px] md:h-[1000px] mt-[-80px]">
          <ZeeroZone className="w-full h-full" />
          {/* <img
            src={ZeeroZone}
            alt="ship and tokens"
            className="w-full h-full"
          /> */}
        </div>
        <div className="mt-[-150px]" id="whatis">
          <div className="pd">
            <h1 className="text-header md:text-large uppercase leading-none text-white text-center">
              what is
            </h1>
            <h1 className="text-header md:text-large uppercase leading-none text-blue text-center">
              zeerozone
            </h1>
          </div>
          <div className="mt-[14px]">
            <p className="pd text-white text-[22px] md:text-[28px] md:max-w-[705px] mx-auto font-zona-semibold text-center">
              Zeerozone is a blockchain-based online game that empowers players
              to explore space
            </p>
            <div className="mt-[38px]">
              <div className="max-w-[1064px] mx-auto">
                <p className="pd text-center text-lightblue font-zona-regular mb-5 leading-[25px]">
                  Players can take ownership of the planets, and navigate the
                  galaxies. Players can build spaceships, and will also have the
                  opportunity to form an alliance with other players. This
                  strong alliance helps players conduct a strategic search
                  towards finding ancient artefacts even in the hidden corners
                  of space. Other alliances are equally searching for artefacts
                  and resources; therefore, the first group to find an artefact
                  takes ownership of it.
                </p>
                <p className="pd text-center text-lightblue font-zona-regular  leading-[25px]">
                  A group of players can also compete against another group
                  towards claiming ownership of a planet. In total, there are
                  nine planets in the Zeerozone space. One of the major features
                  of the games is the space itself where you have spaceships,
                  planets and galaxies. Other features include the marketplace,
                  where players can buy and sell digital assets like NFTs; the
                  $ZEZO token, which is the internal currency of the game; and
                  the Arena, where players can join other players to form an
                  alliance.
                </p>
              </div>
              <div className="w-full overflow-hidden max-h-[880px]">
                <img
                  src={SpaceShip}
                  alt="Spaceship"
                  className="w-full h-full"
                />
              </div>
            </div>
          </div>
          <div className="mt-[34.33px] pd" id="why">
            <h1 className="text-header md:text-large uppercase leading-none text-white text-center">
              why <span className="text-blue">zeerozone?</span>
            </h1>
            <p className="text-white text-[22px] md:text-[28px] font-zona-semibold text-center">
              Many people want to go to space
            </p>
            <p className="mt-[36px] text-center text-lightblue font-zona-regular mb-[64px] xl:max-w-[844px] mx-auto leading-[25px]">
              Over the years, many people have expressed an interest in going to
              space. However, space travel is still expensive{" "}
              <span className="bold">at the moment</span>. In addition, existing
              online games that have attempted to simulate the space experience
              in the past have limitations like inadequate security, poor data
              privacy and confidentiality.{" "}
              <span className="bold">Zeerozone addresses</span> all these
              challenges as it is a blockchain-based online space game built on
              a decentralized network thereby making it transparent and secure.
              Some of the major benefits of the game include the following:
            </p>
            <div className="flex flex-col space-y-[15.93px] items-center xl:flex-row xl:flex-wrap xl:justify-center xl:space-x-[14.67px] xl:gap-[13px]">
              {zeeroZoneBenefits.map((benefit, index) => (
                <Benefit text={benefit} key={index} />
              ))}
            </div>
          </div>
          <div className="relative min-h-[300px]">
            <div className="absolute left-0">
              <img src={Uranus} alt="uranus" />
            </div>
            <div className="absolute right-0 xl:top-[-400px]">
              <img src={Mars} alt="mars" />
            </div>
          </div>
          <div className="mt-[15px] pd" id="vision">
            <h1 className="text-header md:text-large uppercase leading-none text-white text-center mb-[31px]">
              <span className="text-blue">our</span> vision
            </h1>
            <p className="text-center text-lightblue font-zona-regular mb-[52px] leading-[25px] xl:max-w-[850px] mx-auto">
              At Zeerozone, we bring you a best-in-class online blockchain-based
              space game that gives you an incredible space experience. With our
              game, you do not need to spend millions of dollars to go to space.
              You can experience the greatness of space from anywhere by playing
              the Zeerozone game. We have created a game that allows players to
              explore the galaxies, feel the planet, and search for hidden
              artefacts in the forgotten corners of space. We utilized
              blockchain to ensure that the game is built on a decentralized
              network and to empower players with rewards like $ZEZO tokens,
              NFTs, and other digital assets.
            </p>
            <div className="flex flex-col items-center justify-center">
              <span className="text-lightblue2 text-center font-zona-regular">
                Want to go to space?
              </span>
              <p className="text-white text-[22px] xl:text-[28px] font-zona-semibold text-center">
                Join Zeerozone today!
              </p>
              <div className="flex items-center justify-center mt-8">
                <a
                  className="text-white flex items-center justify-between text-mid bg-blue uppercase py-[10px] px-[20px] rounded font-vectro-bold"
                  href="#"
                >
                  join now!
                </a>
              </div>
            </div>
          </div>
          <div className="relative min-h-[600px]">
            <div className="absolute top-[-100px] xl:top-0 right-0">
              <img src={Earth} alt="earth" className="xl:hidden" />
              <img
                src={LargeEarth}
                alt="large earth"
                className="hidden xl:block z-[-1]"
              />
            </div>
            <div className="absolute top-[100px] left-[-50px] xl:left-0 overflow-hidden xl:overflow-visible">
              <img src={SpaceShip2} alt="spaceship2" className="xl:hidden" />
              <img
                src={LargeSpaceShip}
                alt="large spaceship"
                className="hidden xl:block"
              />
            </div>
          </div>
          <div className="pd z-[1] relative" id="features">
            <h1 className="text-header md:text-large text-white text-center leading-none mb-[31px]">
              FEATURES
            </h1>
            <p className="text-center text-lightblue font-zona-regular mb-[61px] xl:max-w-[468px] mx-auto">
              The major features players will encounter in the Zeerozone game
              are described as follows:
            </p>
            <div className="flex flex-col space-y-3 xl:grid xl:grid-cols-3 xl:max-w-[1281px] xl:mx-auto xl:space-x-[14px] xl:space-y-[14px]">
              {ZeeroZoneFeatures.map((feature, index) => (
                <div className="p-[32px] feature" key={index}>
                  {feature.icon}
                  {feature.header}
                  {feature.description}
                </div>
              ))}
            </div>
          </div>
          <div className="pd mt-[81px]" id="nftandgame">
            <h1 className="text-header md:text-large text-white text-center mb-[31px]">
              TOKENS AND NFTS
            </h1>
            <p className="mt-[36px] leading-[25px] text-center text-lightblue font-zona-regular mb-[64px] xl:max-w-[848px] mx-auto">
              The {bolden("$ZEZO")} token is the internal currency of the
              Zeerozone game. This token can be used to purchase digital assets
              like spaceships and ancient artefacts. The tokens owned by a
              player will be deposited in the player’s secure wallet. Also,
              players who own artefacts can mint such assets as NFTs and list
              them for sale on the Zeerozone marketplace. When an alliance (a
              group of players) sells its NFT in exchange for {bolden("$ZEZO")}{" "}
              tokens, the equivalent tokens will be shared among the players in
              the alliance. On the marketplace, digital assets can be exchanged
              for one another; for instance, two artefacts listed for 100{" "}
              {bolden("$ZEZO")} each can be exchanged for a spaceship listed for
              200 {bolden("$ZEZO.")}
            </p>
          </div>
          <div className="mb-[-44px] xl:mb-[-150px]">
            <Space className="w-full" />
          </div>
        </div>
        <div className="roadmap pt-[100px]" id="roadmap">
          <div className="pd">
            <h1 className="text-header md:text-large md:text-center text-white mb-[76.61px]">
              ROADMAP
            </h1>
            <div className="flex flex-col space-y-[76.61px] pb-[137px] xl:max-w-[1000px] xl:mx-auto">
              {roadmaps.map((roadmap, index) => (
                <div
                  className="flex flex-col xl:flex-row xl:space-x-[55px]"
                  key={index}
                >
                  <Diamond className="xl:hidden" />
                  <div className="flex flex-col xl:flex-1">
                    <h1 className="text-white text-header md:text-[48px] mt-[45px] mb-4 xl:m-0">
                      {roadmap.timeline}
                    </h1>
                    <p className="font-zona-semibold text-green text-[26.34px] mb-[23.52px] xl:m-0">
                      {roadmap.header}
                    </p>
                  </div>
                  <LargeDiamond className="hidden xl:block xl:flex-1" />
                  <div className="flex flex-col space-y-[16.94px] xl:flex-1">
                    {roadmap.paths.map((path, index) => (
                      <div className="flex space-x-2" key={index}>
                        <div className="flex-shrink-0">
                          {path.passed ? <Completed /> : <Uncompleted />}
                        </div>
                        <p className="text-white font-zona-regular text-[15.05px]">
                          {path.text}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="translate-y-[20px]">
            <SpaceShipControls />
          </div>
        </div>
        <div className="faqs">
          <div className="pt-[90.29px] pd">
            <h1 className="text-white text-header md:text-large text-center leading-none mb-[76px] xl:max-w-[569px] mx-auto">
              FREQUENTLY ASKED QUESTIONS
            </h1>
            <div className="pd flex flex-col space-y-5 xl:max-w-[849px] xl:mx-auto">
              {faqs.map((faq, index) => (
                <div key={index}>
                  <button className="accordion">
                    <h1 className="text-white text-[32px] uppercase leading-none">
                      {faq.question}
                    </h1>
                  </button>
                  <div className="panel">
                    <p className="text-white font-zona-regular mt-[24px]">
                      {faq.answer}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <Footer />
        </div>
      </div>
    </div>
  );
};

export default Home;
