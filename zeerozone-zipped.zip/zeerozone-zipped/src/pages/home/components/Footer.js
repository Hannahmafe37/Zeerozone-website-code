import { ReactComponent as Logo } from "assets/images/logo.svg";
import { ReactComponent as Telegram } from "assets/icons/social/telegram.svg";
import { ReactComponent as Twitter } from "assets/icons/social/twitter.svg";
// import { ReactComponent as TokenIcon } from "assets/icons/token-icon.svg";
import { socialLinks } from "utils/constants";

const Footer = () => {
  return (
    <div className="flex flex-col xl:flex-row xl:items-center mt-[136px] pb-[26px] xl:mx-[140px]">
      <div className="flex  space-x-[21px] justify-center mb-[26px] xl:mb-0">
        <a
          href={socialLinks.twitter}
          rel="noreferrer"
          target={"_blank"}
          className="w-[50px] h-[50px] rounded-[25px] flex items-center justify-center border-[2px] border-[#957AFF80]/[.2]"
        >
          <Twitter />
        </a>
        <a
          href={socialLinks.telegram}
          rel="noreferrer"
          target={"_blank"}
          className="w-[50px] h-[50px] rounded-[25px] flex items-center justify-center border-[2px] border-[#957AFF80]/[.2]"
        >
          <Telegram />
        </a>
        {/* <div className="w-[73px] h-[73px] rounded-[50%] flex items-center justify-center border-[2px] border-[#957AFF80]/[.2]">
          <TokenIcon className="h-[45px] w-[45px]" />
        </div> */}
      </div>
      <div className="flex flex-col pb-4 items-center justify-center space-y-[26px] xl:flex-row xl:space-y-0 xl:pb-0 xl:justify-between xl:flex-1 xl:ml-[100px]">
        <Logo />
        <p className="text-white/[.5] font-zona-regular text-center lg:text-white">
          ©2022 ZEEROZONE. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default Footer;
